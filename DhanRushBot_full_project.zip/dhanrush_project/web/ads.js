
const cooldown = 60 * 60 * 1000; // 1 hour

function getUid() {
  const params = new URLSearchParams(window.location.search);
  let uid = params.get("uid");
  if (!uid) {
    uid = localStorage.getItem("dhanrush_uid") || "0";
  } else {
    localStorage.setItem("dhanrush_uid", uid);
  }
  return uid;
}

function openAd(network) {
  const now = Date.now();
  const key = "last_" + network;
  const last = localStorage.getItem(key);

  if (last && now - parseInt(last) < cooldown) {
    const mins = Math.ceil((cooldown - (now - last)) / 60000);
    alert(`Please wait ${mins} more minutes before using this option again.`);
    return;
  }

  const uid = getUid();
  if (!uid || uid === "0") {
    alert("User ID missing. Please open this page from the DhanRush bot again.");
    return;
  }

  const pageMap = {
    monetag: "monetag.html",
    adsterra: "adsterra.html",
    unity: "unity.html",
    gamezop: "gamezop.html"
  };

  const page = pageMap[network];
  if (!page) return;

  const url = `${page}?uid=${encodeURIComponent(uid)}&network=${encodeURIComponent(network)}`;
  window.open(url, "_blank");
  localStorage.setItem(key, now.toString());
}
